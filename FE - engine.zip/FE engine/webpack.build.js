// dependencies
const path = require('path')

// environment type
const { NODE_ENV } = process.env;

module.exports = {

    change: [
        // template layout.mako
        {
          file: path.resolve(__dirname, './wsgi', './views/ui/layout.mako'),
          parameters: {
            '/(.*)/header_scripts.(.*).js': NODE_ENV === 'prepare_prod' ? '/static/js/header_scripts.[hash].js' : '/static/js/uncompressed/header_scripts.bundle.js',
            '/(.*)/footer_scripts.(.*).js': NODE_ENV === 'prepare_prod' ? '/static/js/footer_scripts.[hash].js' : '/static/js/uncompressed/footer_scripts.bundle.js'
          }
        },

        // template startLoadTransaction.mako
        {
          file: path.resolve(__dirname, './wsgi', './views/process/pages/startLoadTransaction.mako'),
          parameters: {
            '/(.*)/main.(.*).js': NODE_ENV === 'prepare_prod' ? '/static/js/main.[hash].js' : '/static/js/uncompressed/main.bundle.js'
          }
        },

        // template upgradeIdvDocumentUpload.mako
        {
          file: path.resolve(__dirname, './wsgi', './views/ui/pages/upgradeIdvDocumentUpload.mako'),
          parameters: {
            '/(.*)/main.(.*).js': NODE_ENV === 'prepare_prod' ? '/static/js/main.[hash].js' : '/static/js/uncompressed/main.bundle.js'
          }
        },

        // template idvDocumentUpload.mako
        {
          file: path.resolve(__dirname, './wsgi', './views/ui/pages/idvDocumentUpload.mako'),
          parameters: {
            '/(.*)/main.(.*).js': NODE_ENV === 'prepare_prod' ? '/static/js/main.[hash].js' : '/static/js/uncompressed/main.bundle.js'
          }
        }
    ],

    complete: function(stats) {
      console.log('hash extension added');
    }
}
