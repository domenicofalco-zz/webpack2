// FOOTER SCRIPTS
require('script-loader!./old/vendor/jquery.validate.js');
require('script-loader!./old/vendor/jquery.placeholder.min.js');
require('script-loader!./old/vendor/tabs.min.js');
require('script-loader!./old/vendor/jquery-ui.min.js');

// OTHER SCRIPTS
//require('script-loader!./old/scripts/validate.custom.js');
//require('script-loader!./scripts/validate.order.js');
//require('script-loader!./old/scripts/order-process-card.js');
