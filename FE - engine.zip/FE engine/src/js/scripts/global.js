/************************************************
 * Name:                Bootstrap Scripts
 * Version:             1.0.0
 * Author:              PPRO FE Team
 ***********************************************/

// Classes declaration :: EXAMPLES
class displayMsgInAlert {
  constructor(msg) {
    this.msg = msg;
  }
  show() {
    alert(this.msg)
  }
}

class displayMsgInConsole {
  constructor(msg) {
    this.msg = msg;
  }
  show() {
    console.log(this.msg);
  }
}

// Class instances
const AlertMsg = new displayMsgInAlert('this is an alert msg');
const ConsoleMsg = new displayMsgInConsole('this is ciao');

/*
// Invoke class methods
AlertMsg.show();
ConsoleMsg.show();
*/
