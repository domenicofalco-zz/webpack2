class ScriptExampleTemplate {
  constructor(el) {
    this.$selector = el;
  }

  // the init() method is always required in "Scripts" classes
  init() {
    this.$selector.innerHTML += '<h5><a class="clickMe" href="javascript:void(0);">click me</h3></h5><hr />';

    const anchor = document.getElementsByClassName('clickMe')[0];
    anchor.addEventListener('click', this.alertMsg);
  }

  alertMsg() {
    alert('Click Me!');
  }
}

export default ScriptExampleTemplate;
