/************************************************
 * Name:                Bootstrap Scripts
 * Version:             1.0.0
 * Author:              PPRO FE Team
 ***********************************************/

// Run Global script
require('./global');

// get script-selectors in the markup
const scriptsCollection = document.querySelectorAll('[data-script]');

scriptsCollection.forEach((scriptContainer) => {
  const scriptName = scriptContainer.getAttribute('data-script');
  const Script = require(`./${scriptName}`).default;

  // display launched app in the console
  console.log('Script ->', scriptName);

  new Script(scriptContainer).init();
});
