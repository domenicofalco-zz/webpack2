import { maxWidth } from '../helpers';

class FixedSidebar {
  constructor(el) {
    this.$selector = el;
    this.$wrapper = this.$selector.closest('aside');
    this.previousPosition = window.pageYOffset || document.documentElement.scrollTop;
    this.currentPosition = 0;
    this.disableFixedPosUnder = 767;
    this.isFixed = false;
  }

  init() {
    window.addEventListener('scroll', () => {
      if(maxWidth(this.disableFixedPosUnder)) {
        this.$selector.removeAttribute('style');
      } else {
        this.fixCardPosition();
        this.$selector.style.width = this.getElWidth(this.$wrapper) + 'px';
      }
    });
    window.addEventListener('resize', () => {
      if(maxWidth(this.disableFixedPosUnder)) {
        this.$selector.removeAttribute('style');
      } else {
        this.$selector.style.width = this.getElWidth(this.$wrapper) + 'px';
      }
    });
  }

  fixCardPosition() {
    const $parentWidth = this.getElWidth(this.$wrapper);
    const offset = 96;

    this.currentPosition = window.pageYOffset || document.documentElement.scrollTop;

    // scroll UP
    if (this.previousPosition > this.currentPosition) {
      if(window.scrollY < this.$selector.getBoundingClientRect().top - offset) {
        this.$selector.removeAttribute('style');
      }
    }

    // scroll Down
    else {
      if(this.$selector.getBoundingClientRect().top - offset <= window.scrollY) {
        this.$selector.style.position = 'fixed';
        this.$selector.style.top = offset + 'px';
      }
    }

    this.previousPosition = this.currentPosition;
  }

  getElWidth(el) {
    const styles = window.getComputedStyle(el);
    const padding = parseFloat(styles.paddingLeft) + parseFloat(styles.paddingRight);
    return el.clientWidth - padding;
  }
}

export default FixedSidebar;
