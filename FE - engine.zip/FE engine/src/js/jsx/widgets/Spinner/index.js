// dependencies
import React from 'react';

const Spinner = () =>
  <span className='loading-spinner'>
    <img src='/static/img/spinner.svg' />
  </span>;

export default Spinner;
