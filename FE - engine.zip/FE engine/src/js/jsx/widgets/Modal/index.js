// dependencies
import React from 'react';

// main Modal Wrapper (exported)
const Modal = ({isOpened, updateModalStatus, children, closeCallback, size}) => {
  if(!isOpened) return null;

  return (
    <ModalContent
      closeModal={updateModalStatus}
      closeCallback={closeCallback}
      children={children}
      size={size}
    />
  );
};

// child component (not exported, separated because of animation needs)
class ModalContent extends React.Component {

  constructor(props) {
    super(props);

    this.timing = .8;
    this.TL = new TimelineLite({onReverseComplete: () => { props.closeModal(false) }});
    this.reverseAnimations = this.reverseAnimations.bind(this);
    this.bodyPage = document.getElementsByTagName('body')[0];
  }

  componentWillUnmount() {
    this.bodyPage.classList.remove('has-widget-modal');
  }

  componentWillMount() {
    this.bodyPage.classList.add('has-widget-modal');
  }

  componentDidMount() {
    this.runAnimations();
  }

  runAnimations() {
    const bg = this.modal.querySelector('.widget-modal__bg');
    const content = this.modal.querySelector('.widget-modal__content');

    this.TL.from(bg, this.timing, { opacity: 0 })
      .from(content, this.timing, {
        opacity: 0,
        //y: -250,
        ease: Expo.easeInOut,
        onComplete: () => content.removeAttribute('style')
      }, `-=${this.timing}`);
  }

  reverseAnimations() {
    this.TL.reverse();

    if(this.props.closeCallback) {
      this.props.closeCallback();
    }
  }

  render() {

    const { size } = this.props;
    const sizeClass = size === 'small' ? 'widget-modal__content--small' : '';

    return (
      <div
        ref={(modal) => this.modal = modal}
        className='widget-modal'
      >

        <div
          onClick={this.reverseAnimations}
          className='widget-modal__bg'
        />

        <div className={`widget-modal__content ${sizeClass}`}>
          <span
            className='widget-modal__close glyphicon glyphicon-remove'
            onClick={this.reverseAnimations}
          />

          {this.props.children}
        </div>

      </div>
    );
  }
};

Modal.propTypes = {
  isOpened: React.PropTypes.bool.isRequired,
  updateModalStatus: React.PropTypes.func.isRequired
};

export default Modal;
