// dependencies
import React from 'react';

// components
import SelectCountry from '../../components/SelectCountry';
import GenericSelect from '../../components/GenericSelect';
import UploadDocuments from '../../components/UploadDocuments';

// helper
import { promise } from '../../../helpers';

// app-config
import config from './app-config';

const optionPreSelected = config.docTypeSelectOptions.find(opt => opt.isPreSelected) || config.docTypeSelectOptions[0];

class IDVdocumentUpload extends React.Component {

  constructor() {
    super();

    this.dispatchSelectedCountry = this.dispatchSelectedCountry.bind(this);
    this.dispatchSelectedValue = this.dispatchSelectedValue.bind(this);

    this.state = {
      countrySelected: config.defaultCountry,
      docTypeSelectedVal: optionPreSelected.value
    };
  }

  get preSelectedOption() {
    const findValue = (m) => m['value'] === this.state.docTypeSelectedVal;
    const opt = this.optionList.find(findValue);

    return opt ? opt : this.optionList[0];
  }

  get optionList() {
    const options = config.docTypeSelectOptions;

    if(this.state.countrySelected === 'IE') {
      return options.filter((o, i) => o.value !== 'idcard');
    }

    if(!this.isTrusted) {
      return options.filter((o, i) => o.value !== 'resicendePermit');
    }

    return options;
  }

  get isTrusted() {
    const isTrusted = (countryCode) => config.trustedCountry.includes(countryCode);

    if(isTrusted(config.geoipcountry) || config.geoipcountry === '') {
      return isTrusted(this.state.countrySelected);
    }

    return false;
  }

  get isPorRequired() {
    return (
       !this.isTrusted || this.state.docTypeSelectedVal === 'resicendePermit'
    )
  }

  get showOnlyFront() {
    return this.state.docTypeSelectedVal === 'passport'
  }

  dispatchSelectedCountry(countryCode) {
    this.setState({
      countrySelected: countryCode
    });
  }

  dispatchSelectedValue(opt) {
    this.setState({
      docTypeSelectedVal: opt
    });
  }

  componentDidMount() {
    const postUrlRequest = config.uriApi.getDocumentType;

    promise(postUrlRequest, 'GET', '')
      .then((data) => {
        this.setState({
          docTypeSelectedVal: data.documentType || ''
        });
      })
      .catch((err) => {
        console.log(err);
      });
  }

  render() {
    const {
      formId,
      pageId,
      postProtect,
      currentUserAddress,
      defaultCountry,
      mediators,
      labels,
      errorMessages,
      countriesData,
      uriApi,
      documentsError,
      mimeType,
      maxFileSize,
      geoipcountry
    } = config;

    const { countrySelected, docTypeSelectedVal } = this.state;

    return (
      <div>

        <div className='row'>
          <h5 className='text-highlight col-xs-12'>{labels.mainTitle}</h5>
          <div className='col-xs-12 col-sm-6 mrg-btm-sm'>
            <SelectCountry
              labels={labels}
              formName={countriesData.formName}
              options={countriesData.options}
              defaultCountry={defaultCountry}
              dispatchSelectedCountry={this.dispatchSelectedCountry}
            />
          </div>

          <div className='col-xs-12 col-sm-6 mrg-btm-sm'>
            <GenericSelect
              optionsList={this.optionList}
              optionPreSelected={this.preSelectedOption}
              dispatchSelectedValue={this.dispatchSelectedValue}
            />
          </div>
        </div>

        {errorMessages &&
          <div className='alert alert-danger'>{
            errorMessages.map((err, i) => {
              return (
                <p className='mrg-btm-none' key={i}>{err.text}</p>
              )
            })
          }</div>
        }

        {countrySelected && docTypeSelectedVal &&
          <div className='mrg-btm-sm'>
            <UploadDocuments
              geoipcountry={geoipcountry}
              labels={labels}
              formId={formId}
              pageId={pageId}
              postProtect={postProtect}
              mediators={mediators}
              currentUserAddress={currentUserAddress}
              isPorRequired={this.isPorRequired}
              showOnlyFront={this.showOnlyFront}
              docType={docTypeSelectedVal}
              api={uriApi}
              documentsError={documentsError}
              mimeType={mimeType}
              maxFileSize={maxFileSize}
            />
          </div>
        }
      </div>
    );
  }
};

export default IDVdocumentUpload;
