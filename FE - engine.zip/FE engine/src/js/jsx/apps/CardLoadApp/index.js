// dependencies
import React from 'react';

// components
import SidePanel from '../../components/SidePanel';
import TitleIntrotext from '../../components/TitleIntrotext';
import SelectCountry from '../../components/SelectCountry';
import LoadCardMethods from '../../components/LoadCardMethods';
import IdvLevelStatus from '../../components/IdvLevelStatus';

// Promise
import { Promise } from 'es6-promise';

// widget
import Modal from '../../widgets/Modal';

// app-config
import config from './app-config';

class CardLoadApp extends React.Component {
  constructor() {
    super();

    this.panelData = {};
    this.dispatchSelectedCountry = this.dispatchSelectedCountry.bind(this);
    this.updateModalStatus = this.updateModalStatus.bind(this);
    this.idvLevel = null;

    this.state = {
      countrySelected: config.defaultCountry,
      modalIsOpened: false,
      isUserDataLoading: true,
      userDataMsgErr: ''
    };
  }

  requestPanelUserData() {
    const url = 'balance';
    const request = new XMLHttpRequest();

    return new Promise((resolve, reject) => {
      request.open('GET', url, true);

      request.onload = () => {
        if (request.status >= 200 && request.status < 400) {
          setTimeout(() => {
            resolve(JSON.parse(request.response));
          }, 500)
        }
      };

      request.onerror = () => {
        reject(new Error('Error fetching posts'));
      };

      request.send();
    });
  }

  dispatchSelectedCountry(countryCode) {
    this.setState({
      countrySelected: countryCode
    });
  }

  updateModalStatus(value) {
    this.setState({
      modalIsOpened: value
    });
  }

  checkModalInStorage(showModal) {
    // check if the "modal" can be opened && the browser supports "localStorage"
    if (showModal && typeof localStorage !== 'undefined') {
      const storageKey = 'isIdvModalAlreadyShown';
      const storageValue = localStorage.getItem(storageKey);

      // avoind modal if the "key" has been already set in storage
      if(storageValue !== null) {
        this.setState({
          modalIsOpened: false
        });
      } else {
        this.setState({
          modalIsOpened: true
        });
        localStorage.setItem(storageKey, true);
      }
    }
  }

  componentWillMount() {
    this.requestPanelUserData().then(data => {
      this.idvLevel = data.idv;
      const idvUpgrade2 = '/userportal/MyAccount/upgradeIdvLevel/2/';
      const idvUpgrade3 = '/userportal/MyAccount/upgradeIdvLevel/3/';
      const idvUpgradeActualUrl = this.idvLevel == 1 ? idvUpgrade2 : idvUpgrade3;

      this.panelData = Object.assign({}, {idvPageUrl: idvUpgradeActualUrl}, data);

      this.setState({ isUserDataLoading: false });
      this.checkModalInStorage(data.showWarningModal);

    }).catch(function(e) {
      this.setState({
        isUserDataLoading: false,
        userDataMsgErr: 'data not available'
      });
    });
  }

  get containerClass() {
    if(config.showBalancePanel) {
      return 'col-xs-12 col-sm-8 col-md-9 pull-right';
    }

    return 'col-xs-12 col-xs-offset-0 col-md-10 col-md-offset-1';
  }

  render() {

    const {
      labels,
      paymentMethods,
      userData,
      paymentMsgError,
      showBalancePanel
    } = config;

    const {
      countrySelected,
      modalIsOpened,
      isUserDataLoading,
      userDataMsgErr
    } = this.state;

    return (
      <div className='row'>
        <Modal isOpened={modalIsOpened} updateModalStatus={this.updateModalStatus}>
          <IdvLevelStatus labels={labels} idvLevel={this.idvLevel} panelData={this.panelData} />
        </Modal>

        <div className={this.containerClass}>
          <TitleIntrotext labels={labels} />

          <div className='row'>
            <div className='col-xs-12 col-sm-8 col-md-6 mrg-btm-sm'>
              <SelectCountry
                labels={labels}
                formName={userData.country.formName}
                options={userData.country.options}
                defaultCountry={countrySelected}
                dispatchSelectedCountry={this.dispatchSelectedCountry}
              />
            </div>
          </div>

          <LoadCardMethods
            labels={labels}
            paymentMethods={paymentMethods}
            countrySelected={countrySelected}
            userData={userData}
            paymentMsgError={paymentMsgError}
          />
        </div>

        {showBalancePanel &&
          <aside className='col-xs-12 col-sm-4 col-md-3 pull-left'>
            <SidePanel
              labels={labels}
              idvLevel={this.idvLevel}
              panelData={this.panelData}
              isUserDataLoading={isUserDataLoading}
              userDataMsgErr={userDataMsgErr}
            />
          </aside>
        }
      </div>
    );
  }
};

export default CardLoadApp;
