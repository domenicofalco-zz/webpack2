const config = {
  labels: {
    // component::Balance
    balance: i18n.translate('Balance').fetch(),

    // component::Limit
    limits: i18n.translate('IDV%(level*)s Limit').fetch(),
    limitation: i18n.translate('You can load up to %(idvRemaining*)s until you reach your yearly loading limit of %(idvLimit*)s.').fetch(),
    reminderIdv1: i18n.translate('Upgrade to IDV%(nextLevel*)s to increase your yearly loading limit to %(nextAmountLimit*)s.').fetch(),
    reminderIdv2: i18n.translate('Upgrade to IDV%(nextLevel*)s - with IDV%(nextLevel*)s no general loading limits apply to your account.').fetch(),
    upgradeLinkText: i18n.translate('Upgrade now').fetch(),

    // component::TitleIntrotext
    mainTitle: !isAppSession ? i18n.translate('Load your account').fetch() : '', // In case of "mobile app" session, the title need to be hidden
    introText: i18n.translate('Loading your account is easy. Simply select your country for unique loading methods, then the method of your choice. Individual loading limits per method may apply based on your identification level and account history.').fetch(),

    // component::SelectCountry
    selectCountryText: '',

    // component::LoadCardMethods
    selectPayment: i18n.translate('Please select a loading method').fetch(),
    amountText: i18n.translate('Amount').fetch(),
    ibanText: i18n.translate('Account Number / IBAN').fetch(),
    bicText: i18n.translate('Bank Code / BIC').fetch(),
    submit: i18n.translate('Continue').fetch(),
    knownAccountsText: i18n.translate('Select previously used account...').fetch(),
    methodsDescriptions: [
      {
        name: 'ukash',
        descriptions: [i18n.translate('If you have more than one Ukash voucher you can combine your smaller vouchers into one new voucher.').fetch()],
        link: {
          text: i18n.translate('Click here for more information on combining vouchers at Ukash.').fetch(),
          href: 'http://www.ukash.com/',
          target: '_new'
        }
      },
      {
        name: 'giropay',
        descriptions: [i18n.translate('giropay works with Postbank, Sparkassen, Volks- and Raiffeisenbanks and with many others.').fetch()],
        link: {
          text: i18n.translate('Click here for a list of all banks who offer giropay instant transfers.').fetch(),
          href: 'http://www.giropay.de/index.php?id=banken_check',
          target: '_new'
        }
      },
      {
        name: 'directpay',
        descriptions: [
          i18n.translate(`SOFORT Banking is the direct payment method of SOFORT AG. SOFORT Banking allows you to directly and automatically trigger a credit transfer during your online purchase with your online banking information. A transfer order is instantly confirmed to %(ShortProductName)s allowing an instant load of your card account. SOFORT Banking has been certified by Europe's largest quality and security institute, the TÜV, according to best-practice data privacy standards. There is no need for an additional registration or a credit card.`).fetch().replace(`%(ShortProductName)s`, ShortProductName),
          i18n.translate('You may load your card with SOFORT Banking up to EUR 150 per week initially. This restriciton is lifted one week after the first successful SOFORT Banking transaction.').fetch()
        ]
      },
      {
        name: 'germanDomesticWire',
        descriptions: [i18n.translate('Please initiate a transfer to the bank details provided here after the below confirmation.').fetch()]
      },
      {
        name: 'polishDomesticWire',
        descriptions: [i18n.translate('Please initiate a transfer to the bank details provided here after the below confirmation.').fetch()]
      },
      {
        name: 'sepaWire',
        descriptions: [i18n.translate('SEPA standard transfers need to be in EUR currency and are valid up to 50,000 EUR per transfer. Please initiate a SEPA standard transfer to the bank details provided here after the below confirmation.').fetch()]
      },
      {
        name: 'internationalWire',
        descriptions: [i18n.translate('International bank transfers can be in any currency and for an unlimited amount. Please initiate an international bank transfer to the bank details provided here after the below confirmation.').fetch()]
      },
      {
        name: 'cashDepositGermanBank',
        descriptions: [i18n.translate('Banks offering this service in Germany include Postbank, Deutsche Bank, Commerzbank, Sparkasse, Reisebank and many more. Further information including the required bank details will be provided after you confirm the amount you want to load.').fetch()]
      },
      {
        name: 'ideal',
        descriptions: [
          i18n.translate('If you already have online banking with ABN AMRO, ASN Bank, Friesland Bank, ING, Knab, RegioBank, SNS Bank, Triodos Bank or Van Lanschot Bankiers, you can load your %(ShortProductName)s card account using iDEAL right away').fetch().replace('%(ShortProductName)s', ShortProductName),
          i18n.translate('You may load your card with iDEAL up to EUR 150 per week initially. This restriciton is lifted four weeks after the first successful iDEAL transaction is credited to your card.').fetch()
        ]
      },
      {
        name: 'eps',
        descriptions: [i18n.translate('If you already have online banking with an Austrian Volks- or Raiffeisenbank or one of many others, you can load your %(ShortProductName)s card account using eps right away').fetch().replace('%(ShortProductName)s', ShortProductName)],
        link: {
          text: i18n.translate('Click here for a list of all banks who offer eps instant transfers.').fetch(),
          href: 'https://www.volksbank.at/private/electronic_banking/eps_online_ueberweisung',
          target: '_new'
        }
      },
      {
        name: 'bitpay',
        descriptions: [i18n.translate('Simply enter the amount in %(accountCurrency)s you would like to load  with your Bitcoin wallet.').fetch().replace('%(accountCurrency)s', m.currency.value)]
      },
      {
        name: 'instanttransfer',
        descriptions: [
          i18n.translate('InstantTransfer is much more convenient than a usual bank transfer:').fetch(),
          i18n.translate('Select your own bank, log in with your usual online banking credentials and enter your TAN. Done!').fetch()
        ],
        list: [
          i18n.translate('all necessary data is already prefilled').fetch(),
          i18n.translate('no registration').fetch(),
          i18n.translate('transfer will be initiated by your own bank as usual').fetch(),
          i18n.translate('as secure as a usual bank transfer').fetch(),
        ],
        link: {
          text: i18n.translate('For more information about InstantTransfer click here.').fetch(),
          href: 'https://instanttransfer.com',
          target: '_new'
        },
        subDescription: [i18n.translate('You may load your card account with InstantTransfer up to 150 EUR per week initially. This restriction is lifted one week after the first successful InstantTransfer deposit.').fetch()]
      },
    ],

    // component::idvLevelStatus (Modal)
    modalTitle: i18n.translate(`You're about to reach your IDV limit!`).fetch(),
    modalDescriptions: i18n.translate('With your current identification level IDV%(level*)s you can load your account with up to %(limit*)s per year.').fetch(),
    modalDescriptionsIdv1: i18n.translate('To increase your yearly limit to %(nextAmountLimit*)s please %(upgrade to*) IDV%(idvNextLevel*)s.').fetch(),
    modalDescriptionsIdv2: i18n.translate('Upgrade to IDV%(idvNextLevel*)s - with IDV%(idvNextLevel*)s no general loading limits apply to your account.').fetch(),
    modalDescriptionsGeneric: i18n.translate('Upgrading is easy and for free - simply upload the required documents for review and we will notify you when the upgrade is complete.').fetch(),
    modalLinkText: i18n.translate('Upgrade now').fetch(),
    modalLinkRejectText: i18n.translate(`I don't want higher limits`).fetch(),
  },

  // generic app's data
  userData: m,
  paymentMsgError: errorMessages,
  showBalancePanel,

  // component::SelectCountry
  defaultCountry: m.country.value || defaultCountry || 'DE',

  // component::LoadCardMethods
  paymentMethods: methods,

};

export default config;
