const baseUrl = window.location.href;
const config = {

  labels: {
    mainTitle: i18n.translate('Select the country your photo ID document was issued and the type of photo ID document you would like to upload.').fetch(),
    uploadTitle: i18n.translate('Please upload your documentation').fetch(),
    frontPassportLabel: i18n.translate('Pic of ID Passport').fetch(),
    frontLabel: i18n.translate('Front side').fetch(),
    backLabel: i18n.translate('Back side').fetch(),
    porLabel: i18n.translate('Proof of residence').fetch(),
    chooseFileText: i18n.translate('Choose a file').fetch(),
    previewFileText: i18n.translate('Preview').fetch(),
    deleteFileText: i18n.translate('Delete').fetch(),
    uploadButton: i18n.translate('Finish').fetch(),
    step1: i18n.translate('Uploade ID document/s').fetch(),
    step2: i18n.translate('Upload address verification').fetch(),
    docIdDescriptin: {
      title: i18n.translate('Please ensure you follow the below specifications:').fetch(),
      list: [
        i18n.translate('description list').fetch(),
        i18n.translate('description list').fetch(),
        i18n.translate('description list').fetch()
      ]
    },
    porDescription1: {
      title: i18n.translate('Specifications for proof of residence:').fetch(),
      list: [
        i18n.translate('description list').fetch(),
        i18n.translate('description list').fetch(),
        i18n.translate('description list').fetch(),
      ]
    },
    porDescription2: {
      title: i18n.translate('The following will be accepted as a proof of residence:').fetch(),
      list: [
        i18n.translate('description list').fetch(),
        i18n.translate('description list').fetch(),
      ]
    },

    modalAddress: {
      title: i18n.translate('your viabuy address').fetch(),
      subTitle: i18n.translate('Please ensure the below address is correct and matches that of the document you are uploading.').fetch(),
      linkText: i18n.translate('Edit my address').fetch(),
      closeText: i18n.translate('Close').fetch()
    },

    modalSubmitted: {
      title: i18n.translate('thank you for upgrading your idv level.').fetch(),
      text: i18n.translate('We are currently reviewing your documents. On approval, you will be upgraded to IDV Level 2.').fetch(),
      closeText: i18n.translate('Close').fetch()
    }
  },

  // generic app's data
  formId: idvProperties.formId,
  mediators: idvProperties.mediators,
  pageId: idvProperties.pageId,
  postProtect: idvProperties.postProtect,
  currentUserAddress: currentAddress,
  geoipcountry: geoipcountry || '',

  // component::SelectCountry
  countriesData,
  defaultCountry,

  docTypeSelectOptions: [
    {
      label: i18n.translate('Please select the type of ID Document').fetch(),
      value: '',
      isPreSelected: false
    },
    {
      label: i18n.translate('Passport').fetch(),
      value: 'passport',
      isPreSelected: false
    },
    {
      label: i18n.translate('National ID card').fetch(),
      value: 'idcard',
      isPreSelected: false
    },
    {
      label: i18n.translate('Diver licence').fetch(),
      value: 'diverLicence',
      isPreSelected: false
    },
    {
      label: i18n.translate('Resicende permit').fetch(),
      value: 'resicendePermit',
      isPreSelected: false
    }
  ],

  errorMessages: errorMessages,

  mimeType: ['image/jpeg', 'image/png', 'image/tiff', 'image/gif', 'image/bmp', 'application/pdf'],
  maxFileSize: 1024*1024*10, // FIXME: we should get this value from the configuration
  documentsError: {
    docNotSupported: 'Format not supported',
    docRemoveError: 'Cannot remove the document',
    docLoadedError: 'Loading error',
    docErrorSize: 'Too big',
  },

  trustedCountry: [
    'AT',
    'BE',
    'BG',
    'HR',
    'CY',
    'CZ',
    'DK',
    'EE',
    'FI',
    'FR',
    'DE',
    'GR',
    'GI',
    'HU',
    'IE',
    'IT',
    'LV',
    'LT',
    'LU',
    'MT',
    'MC',
    'NL',
    'PL',
    'PT',
    'RO',
    'SM',
    'SK',
    'SI',
    'ES',
    'SE',
    'CH',
    'GB',
    'IS',
    'LI',
    'NO'
  ],

  uriApi: {
    getDocumentType: baseUrl + '/idv/getCurrentType',
    postUploadFile: baseUrl + '/idv/uploadDocument',
    postRemoveFile: baseUrl + '/idv/removeDocument',
    getDocumentsNotApproved: baseUrl + '/idv/getDocumentsWaitingForApproval',
    getApprovedDocuments: baseUrl + '/idv/getApprovedDocuments',
    submitFiles: baseUrl + '/idv/finish'
  }

};

export default config;
