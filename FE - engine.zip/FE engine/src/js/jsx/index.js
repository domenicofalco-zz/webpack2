/************************************************
 * Name:                Bootstrap React Apps
 * Version:             1.0.0
 * Author:              PPRO FE Team
 ***********************************************/


// dependencies
import React from 'react';
import ReactDOM from 'react-dom';

// get app-selectors in the markup
const appsCollection = document.querySelectorAll('[data-react-app]');

appsCollection.forEach((appsContainer) => {
  const appName = appsContainer.getAttribute('data-react-app');
  const App = require(`./apps/${appName}/index`).default;

  // display launched app in the console
  console.log('React App ->', appName);

  ReactDOM.render(<App />, appsContainer);
});
