// dependencies
import React from 'react';

// components
import InputFileBlock from './InputFileBlock';
import Descriptions from './Descriptions';
import CurrentUserAddress from './CurrentUserAddress';
import SubmitModal from './SubmitModal';
import StepCounter from './StepCounter';
import Spinner from '../../widgets/Spinner';

// helper
import { promise } from '../../../helpers';

// widget
import Modal from '../../widgets/Modal';

class UploadDocuments extends React.Component {
  constructor(props) {
    super(props);

    this.setInputsStatus = this.setInputsStatus.bind(this);
    this.updateModalStatus = this.updateModalStatus.bind(this);
    this.modalOnClose = this.modalOnClose.bind(this);
    this.changeDocumentSlide = this.changeDocumentSlide.bind(this);
    this.submitForm = this.submitForm.bind(this);
    this.isSubmitted = false;

    this.state = {
      uploadFrontId: {},
      uploadBackId: {},
      uploadPor: {},
      modalIsOpened: false,
      isLoading: false,
      slideToShow: {
        name: 'id-documents',
        percentage: 0
      }
    };
  }

  get isValidForm() {
    const { uploadFrontId, uploadBackId, uploadPor } = this.state;
    const { showOnlyFront, isPorRequired } = this.props;

    if(showOnlyFront) {
      if(isPorRequired) {
        return uploadFrontId.isValid && uploadPor.isValid;
      }

      return uploadFrontId.isValid;
    }

    if(isPorRequired) {
      return uploadFrontId.isValid && uploadBackId.isValid && uploadPor.isValid;
    }

    return uploadFrontId.isValid && uploadBackId.isValid;
  }

  updateModalStatus(value) {
    this.setState({
      modalIsOpened: value
    });
  }

  modalOnClose() {
    if(this.isSubmitted) {
      window.location.href = '/';
    }
  }

  setInputsStatus(id, isValid, error) {
    this.setState({
      [id]: {
        isValid,
        error
      }
    });
  }

  changeDocumentSlide(slideToShow, perc) {
    this.setState({
      slideToShow: {
        name: slideToShow,
        percentage: perc
      }
    });
  }

  submitForm(e, slideToShow, perc) {
    e.preventDefault();

    const urlRequest = this.props.api.submitFiles;

    const formName = document.getElementsByName('formName')[0].value;
    const pageId = document.getElementsByName('pageId')[0].value;
    const postProtect = document.getElementsByName('postProtect')[0].value;

    let formData = new FormData(this.form);
    formData.append('formName', formName);
    formData.append('pageId', pageId);
    formData.append('postProtect', postProtect);

    this.setState({
      isLoading: true
    });

    promise(urlRequest, 'POST', formData, false)
      .then(() => {
        this.isSubmitted = true;

        if(this.props.isPorRequired) {
          // slider animation
          this.changeDocumentSlide(slideToShow, perc);
        }

        this.setState({
          isLoading: false,
          modalIsOpened: true
        });

      })
      .catch((err) => {
        console.log('ERROR:', err);
      });
  }

  componentWillReceiveProps(nextProps) {
    // set default "slide" state
    if(!nextProps.isPorRequired) {
      this.setState({
        slideToShow: {
          name: 'id-documents',
          percentage: 0
        }
      });
    }
  }

  render() {
    const {
      labels,
      mediators,
      currentUserAddress,
      formId,
      pageId,
      postProtect,
      showOnlyFront,
      isPorRequired,
      docType,
      api,
      documentsError,
      mimeType,
      maxFileSize
    } = this.props;

    const {
      modalIsOpened,
      uploadFrontId,
      uploadBackId,
      uploadPor,
      slideToShow,
      isLoading
    } = this.state;

    const errorTemplate = (() => {
      return (
        <div>
          {uploadFrontId.error &&
            <div className='alert alert-danger'>
              <p className='mrg-btm-none'>{showOnlyFront ? labels.frontPassportLabel : labels.frontLabel}: {uploadFrontId.error}</p>
            </div>
          }

          {uploadBackId.error &&
            <div className='alert alert-danger'>
              <p className='mrg-btm-none'>{labels.backLabel}: {uploadBackId.error}</p>
            </div>
          }

          {uploadPor.error &&
            <div className='alert alert-danger'>
              <p className='mrg-btm-none'>{labels.porLabel}: {uploadPor.error}</p>
            </div>
          }
        </div>
      );
    })();

    const modalView = (() => {
      if(this.isSubmitted) {
        return <SubmitModal labels={labels} />
      }
      return <CurrentUserAddress currentUserAddress={currentUserAddress} labels={labels} />;
    })();

    const isNextBtnDisabled = (() => {
      if(showOnlyFront) return uploadFrontId.isValid;
      else return uploadFrontId.isValid && uploadBackId.isValid
    })();

    return (
      <form
        id='form-data'
        ref={ref => this.form = ref}
        onSubmit={e => this.submitForm(e, 'proof-of-residence', 100)}
        id={formId}
        method='POST'
        className='row'
        encType='multipart/form-data'
        noValidate='novalidate'
      >

        <input type='hidden' name='formName' value={formId} />
        <input type='hidden' name='pageId' value={pageId} />
        <input type='hidden' name='postProtect' value={postProtect} />

        <Modal isOpened={modalIsOpened} updateModalStatus={this.updateModalStatus} closeCallback={this.modalOnClose} size='small'>
          {modalView}
        </Modal>

        <div className='doc-upload col-xs-12'>

          {isPorRequired &&
            <StepCounter slideToShow={slideToShow} labels={labels} />
          }

          <h5 className='text-highlight'>{labels.uploadTitle}</h5>

          {errorTemplate}

          <div className={'doc-upload__slide' + (slideToShow.name === 'id-documents' ? ' doc-upload__slide--is-active' : '')}>
            <div className='doc-upload__container col-xs-12'>

              {isLoading && <Spinner />}

              <div className='col-xs-4 col-sm-3 col-md-2 doc-upload__left'>

                <InputFileBlock
                  id='uploadFrontId'
                  labels={labels}
                  title={showOnlyFront ? labels.frontPassportLabel : labels.frontLabel}
                  mediators={mediators['m1']}
                  setInputsStatus={this.setInputsStatus}
                  docType={docType}
                  api={api}
                  formRef={this.form}
                  documentsError={documentsError}
                  mimeType={mimeType}
                  maxFileSize={maxFileSize}
                />

                {!showOnlyFront &&
                  <InputFileBlock
                    id='uploadBackId'
                    labels={labels}
                    title={labels.backLabel}
                    mediators={mediators['m2']}
                    setInputsStatus={this.setInputsStatus}
                    docType={docType}
                    api={api}
                    formRef={this.form}
                    documentsError={documentsError}
                    mimeType={mimeType}
                    maxFileSize={maxFileSize}
                  />
                }
              </div>

              <div className='col-xs-8 col-sm-9 col-md-10 doc-upload__right'>
                <Descriptions labels={labels.docIdDescriptin} />
              </div>
            </div>

            {isPorRequired &&
              <div className='pull-right'>
                <button
                  type='button'
                  onClick={e => this.changeDocumentSlide('proof-of-residence', 50)}
                  className='doc-upload__submit btn btn-xcard-main'
                  disabled={!isNextBtnDisabled}
                >
                  Next
                </button>
              </div>
            }
          </div>

          {isPorRequired &&
            <div className={'doc-upload__slide' + (slideToShow.name === 'proof-of-residence' ? ' doc-upload__slide--is-active' : '')}>
              <div className='doc-upload__container col-xs-12'>

                {isLoading && <Spinner />}

                <div className='col-xs-4 col-sm-3 col-md-2 doc-upload__left'>
                  <InputFileBlock
                    id='uploadPor'
                    labels={labels}
                    title={labels.porLabel}
                    mediators={mediators['m3']}
                    setInputsStatus={this.setInputsStatus}
                    docType={docType}
                    api={api}
                    formRef={this.form}
                    documentsError={documentsError}
                    mimeType={mimeType}
                    maxFileSize={maxFileSize}
                  />

                </div>

                <div className='col-xs-8 col-sm-9 col-md-10 doc-upload__right'>
                  <div>
                    <Descriptions labels={labels.porDescription1} />
                    <Descriptions
                      labels={labels.porDescription2}
                      updateModalStatus={this.updateModalStatus}
                    />
                  </div>
                </div>
              </div>

              <div className='pull-right'>
                <button
                  type='button'
                  onClick={e => this.changeDocumentSlide('id-documents', 0)}
                  className='doc-upload__back btn btn-default'
                >
                  Back
                </button>

                <button
                  className='doc-upload__submit btn btn-xcard-main'
                  type='submit'
                  disabled={!this.isValidForm}
                >
                  {labels.uploadButton}
                </button>
              </div>
            </div>
          }

          {!isPorRequired &&
            <div className='pull-right'>
              <button
                className='doc-upload__submit btn btn-xcard-main'
                type='submit'
                disabled={!this.isValidForm}
              >
                {labels.uploadButton}
              </button>
            </div>
          }

        </div>
      </form>
    );
  }
};

UploadDocuments.propTypes = {
  labels: React.PropTypes.object
};

export default UploadDocuments;
