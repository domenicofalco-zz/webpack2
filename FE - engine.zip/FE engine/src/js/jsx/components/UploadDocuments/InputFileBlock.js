// dependencies
import React from 'react';

// widget
import Modal from '../../widgets/Modal';
import Spinner from '../../widgets/Spinner';

// helper
import { promise } from '../../../helpers';

class InputFileBlock extends React.Component {
  constructor(props) {
    super(props);

    this.updateModalStatus = this.updateModalStatus.bind(this);

    this.inputId = props.id;
    this.error = false;
    this.isUploaded = false;
    this.imgBase64 = '';
    this.errorMsg = this.props.documentsError;

    this.documentSelected = (() => {
      if(this.inputId === 'uploadFrontId') {
        return 'photo-id-front'
      }
      if(this.inputId === 'uploadBackId') {
        return 'photo-id-back'
      } else {
        return 'utility-bill'
      }
    })();

    this.state = {
      isLoading: false,
      modalIsOpened: false,
      isApproved: false
    };
  }

  dispatchInputState() {
    this.props.setInputsStatus(this.inputId, this.isUploaded, this.error);
  }

  updateModalStatus(value) {
    this.setState({
      modalIsOpened: value
    });
  }

  uploadDocument(e) {
    const mimeType = this.props.mimeType;
    const maxFileSize = this.props.maxFileSize;

    const file = this.input.files[0];
    const fileType = file.type;
    const fileSize = file.size;

    const isFileTypeValid = mimeType.includes(fileType);
    const isFileSizeValid = fileSize < maxFileSize;

    if(isFileTypeValid && isFileSizeValid) {
      const postUrlRequest = this.props.api.postUploadFile;

      this.setState({
        isLoading: true
      });

      const documentSide = this.inputId === 'uploadBackId' ? 'back' : 'front';
      const documentType = this.inputId === 'uploadPor' ? 'utility-bill' : this.props.docType;

      let formData = new FormData(this.props.formRef);
      formData.append('documentSide', documentSide);
      formData.append('documentType', documentType);
      formData.append('idvupload-upload-documents-upload', file);

      promise(postUrlRequest, 'POST', formData, false)
        .then((data) => {
          this.setState({
            isLoading: false
          });
        })
        .then(() => {
          // request the document just uploaded
          this.getDocumentsWaitingForApproval();
        })
        .catch((err) => {

          this.setState({
            isLoading: false,
          });

          //
          this.error = err.message;
          this.isUploaded = false;
          this.dispatchInputState();
        });

    } else {
      const { docNotSupported, docErrorSize } = this.errorMsg;
      this.error = !isFileTypeValid ? docNotSupported : docErrorSize;
      this.isUploaded = false;
      this.dispatchInputState();
    }
  }

  removeDocument(e) {
    e.preventDefault();
    const urlRequest = this.props.api.postRemoveFile;

    this.imgBase64 = '';

    this.setState({
      isLoading: true
    });

    let formData = new FormData(this.props.formRef);
    formData.append('documentId', this.documentId);

    promise(urlRequest, 'POST', formData, false)
      .then(() => {
        this.setState({
          isLoading: false
        });

        //
        this.isUploaded = false;
        this.error = false;
        this.dispatchInputState();
      })
      .catch(() => {
        this.setState({
          isLoading: false
        });

        //
        this.error = this.errorMsg.docRemoveError;
        this.isUploaded = false;
        this.dispatchInputState();
      });
  }

  getDocumentsWaitingForApproval() {
    const urlRequest = this.props.api.getDocumentsNotApproved;
    this.setState({
      isLoading: true
    });

    promise(urlRequest, 'GET', '', false)
      .then((data) => {
        const hasDocument = data.documents[this.documentSelected] ? true : false;
        this.isUploaded = false;

        if(hasDocument) {
          this.isUploaded = true;

          const document = data.documents[this.documentSelected];
          const imgType = `data:${document['type']};base64,`;
          const url = imgType + document['raw-data'];
          this.documentId = document.id;

          // http request for the picture in order to cache it in advance
          var img = new Image();
          img.src = url;
          this.imgBase64 = img.src;
        }

        //
        this.error = false;
        this.dispatchInputState();
      })
      .then(() => {
        this.setState({
          isLoading: false,
        });
      })
      .catch(() => {
        this.imgBase64 = '';

        this.setState({
          isLoading: false
        });

        this.error = this.errorMsg.docLoadedError;
        this.isUploaded = false;
        this.dispatchInputState();
      });
  }

  getApprovedDocuments() {
    const urlRequest = this.props.api.getApprovedDocuments;

    this.setState({
      isLoading: true
    });

    promise(urlRequest, 'GET', '', false)
      .then((data) => {
        const isApproved = data.includes(this.documentSelected)

        this.setState({
          isLoading: false,
          isApproved
        });

        if(isApproved) {
          this.isUploaded = true;
          this.error = false;
          this.dispatchInputState();
        } else {
          /*
            if this document is not in the "approved list",
            let's look for it in the "waiting list"
          */
          this.getDocumentsWaitingForApproval();
        }
      })
      .catch(() => {
        this.setState({
          isLoading: false
        });

        //
        this.error = this.errorMsg.docLoadedError;
        this.isUploaded = false;
        this.dispatchInputState();
      });
  }

  componentDidMount() {
    this.getApprovedDocuments();
  }

  get currentField() {
    const { mediators, labels } = this.props;
    const idField = mediators.upload.formName;

    if(this.state.isApproved) {
      return (
        <span className='doc-upload__options'>
          <i className='doc-upload__icon glyphicon glyphicon-ok-circle doc-upload__icon--green' />
          Approved
        </span>
      )
    } else {
        if(this.imgBase64 !== '') {
          return (
            <span className='doc-upload__options'>
              <i className='doc-upload__icon glyphicon glyphicon-ok-circle' />
              <a className='doc-upload__choosetext' href='javascript:void(0);' onClick={() => this.updateModalStatus(true)}>
                {labels.previewFileText}
              </a>
              <i className='doc-upload__separator'>|</i>
              <a className='doc-upload__choosetext' href='javascript:void(0);' onClick={(e) => this.removeDocument(e)}>
                {labels.deleteFileText}
              </a>
            </span>
          )
        }
        else {
          return (
            <div>
              <span className='doc-upload__options'>
                <i className='doc-upload__icon glyphicon glyphicon-open' />
                <a className='doc-upload__choosetext' href='javascript:void(0);'>{labels.chooseFileText}</a>
              </span>
              <input
                id={this.inputId}
                ref={ref => this.input = ref}
                name={idField}
                type='file'
                className='doc-upload__input'
                onChange={(e) => this.uploadDocument(e)}
              />
            </div>
          )
        }
    }
  }

  render() {
    const { isLoading, modalIsOpened, isApproved } = this.state;
    const chooseClass = this.imgBase64 === '' && !isApproved ? ' doc-upload__choosefile--notloaded' : '';
    const errorClass = this.error ? ' doc-upload--error' : '';

    return (
      <div className='doc-upload__fieldset'>
        {this.imgBase64 &&
          <Modal isOpened={modalIsOpened} updateModalStatus={this.updateModalStatus}>
            <img src={this.imgBase64} />
          </Modal>
        }
        <label className='doc-upload__label'>{this.props.title}</label>
        <span className={`doc-upload__choosefile${chooseClass}${errorClass}`}>
          {isLoading && <Spinner />}
          {this.currentField}
        </span>
      </div>
    );
  }
};

export default InputFileBlock;
