// dependencies
import React from 'react';

class SubmitModal extends React.Component {
  render() {
    const labels = this.props.labels.modalSubmitted;

    return (
      <div className='submit-modal'>
        <i className='submit-modal__icon glyphicon glyphicon-ok' />
        <h5 className='text-highlight'>{labels.title}</h5>
        <p>{labels.text}</p>
      </div>
    );
  }
}

export default SubmitModal;
