// dependencies
import React from 'react';

class CurrentUserAddress extends React.Component {
  triggerCloseClick(e) {
    e.preventDefault(e);

    const closeSelector = e.target.closest('.widget-modal__content').querySelector('.widget-modal__close');
    closeSelector.click();
  }

  render() {
    const labels = this.props.labels.modalAddress;
    const cua = this.props.currentUserAddress;

    return (
      <div className='cua'>
        <h5 className='text-highlight'>{labels.title}</h5>
        <p>{labels.subTitle}</p>

        <div className='cua__info'>
          {cua.address &&
            <span>{cua.address}</span>
          }
          {cua.address2 &&
            <span>{cua.address2}</span>
          }
          {cua.postCode &&
            <span>{cua.postCode}</span>
          }
          {cua.city &&
            <span>{cua.city}</span>
          }
          {cua.countryName &&
            <span>{cua.countryName}</span>
          }
          {cua.changeAddressLink &&
            <a className='btn btn-default mrg-top-sm' href={cua.changeAddressLink}>
              {labels.linkText}
            </a>
          }
        </div>

        <a
          href='#'
          className='btn btn-xcard-main mrg-top-single mrg-left-xs pull-right'
          onClick={(e) => this.triggerCloseClick(e)}
        >
            {labels.closeText}
        </a>
      </div>
    );
  }
}

export default CurrentUserAddress;
