// dependencies
import React from 'react';

class Descriptions extends React.Component {
  createMarkup(text) {
    return {__html: text};
  }

  componentDidMount() {
    const showAddressBtn = this.ul.querySelector('a');

    if(showAddressBtn) {
      showAddressBtn.addEventListener('click', (e) => {
        const isOpenerModal = JSON.parse(e.target.getAttribute('data-open-modal'));

        if(isOpenerModal) {
          e.preventDefault();
          this.props.updateModalStatus(true);
        }

      });
    }
  }

  render() {
    const { title, list } = this.props.labels;

    return (
      <div className='doc-upload__description'>
        <span className='doc-upload__title'>{title}</span>
        <ul className='doc-upload__text' ref={(ul) => this.ul = ul}>
          {list.map((text, i) => <li key={i} dangerouslySetInnerHTML={this.createMarkup(text)} />)}
        </ul>
      </div>
    );
  }
}

export default Descriptions;
