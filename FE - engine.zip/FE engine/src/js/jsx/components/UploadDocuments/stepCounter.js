// dependencies
import React from 'react';

class StepCounter extends React.Component {
  render() {
    const { slideToShow, labels } = this.props;

    const step1 = (() => {
      if(slideToShow.percentage >= 50) {
        return 'done'
      }

      return 1;
    })();

    const step2 = (() => {
      if(slideToShow.percentage === 100) {
        return 'done'
      }

      return 2;
    })();

    return (
      <div className='step-counter row'>
        <div className='col-xs-6 step-counter__col'>
          <span className={`step-counter__num step-counter__num--${step1}`} />
          <span className='step-counter__text'>{labels.step1}</span>
        </div>
        <div className='col-xs-6 step-counter__col'>
          <span className={`step-counter__num step-counter__num--${step2}`} />
          <span className='step-counter__text'>{labels.step2}</span>
        </div>
        <div className='step-counter__bar col-xs-12 step-counter__col'>
          <div
            className={`step-counter__status`}
            style={{width: slideToShow.percentage + '%'}}
          />
        </div>
      </div>
    );
  }
}

export default StepCounter;
