import React from 'react';

const Balance = ({ balance, labels, currency }) => (
  <div className='loadcard-panel__balance'>
    <span className='loadcard-panel__title'>{labels.balance}</span>
    <strong className='loadcard-panel__amount'>{balance} <em>{currency}</em></strong>
  </div>
);

export default Balance;
