// dependencies
import React from 'react';

// components
import Balance from './Balance';
import Limit from './Limit';

// widget
import Spinner from '../../widgets/Spinner';

// js custom plugin
import FixedSidebar from '../../../scripts/fixedSidebar';

class SidePanel extends React.Component {
  constructor(props) {
    super(props);

    this.openLimitTab = this.openLimitTab.bind(this);
    this.state = { isLimitPanelOpened: true };
  }

  openLimitTab(e) {
    e.preventDefault();

    this.setState((prevState) => {
      return {
        isLimitPanelOpened: !prevState.isLimitPanelOpened
      }
    });
  }

  componentDidMount() {
    let fixedSidebar = new FixedSidebar(this.el);
    fixedSidebar.init();
  }

  render() {
    const { labels, panelData, isUserDataLoading, userDataMsgErr, idvLevel } = this.props;
    const { currency, totalBalance } = panelData
    const { isLimitPanelOpened } = this.state;

    if(isUserDataLoading) {
      return <div ref={el => this.el = el} className='loadcard-panel loadcard-panel--isLoading'>
        <Spinner />
      </div>
    }

    if(userDataMsgErr) {
      return <div ref={el => this.el = el} className='loadcard-panel loadcard-panel--isLoading'>
        {userDataMsgErr}
      </div>
    }

    return (
      <div
        ref={el => this.el = el}
        className='loadcard-panel'
      >
        <Balance
          labels={labels}
          currency={currency}
          balance={panelData.availableBalance}
        />
        {idvLevel !== 3 &&
          <Limit
            labels={labels}
            isLimitPanelOpened={isLimitPanelOpened}
            openLimitTab={this.openLimitTab}
            panelData={panelData}
            idvLevel={idvLevel}
          />
        }
      </div>
    );
  }
};

SidePanel.propTypes = {
  labels: React.PropTypes.object
};

export default SidePanel;
