// dependencies
import React from 'react';

// import animation api
import TransitionGroup from 'react-addons-transition-group';

const Limit = ({ labels, isLimitPanelOpened, openLimitTab, panelData, idvLevel }) => {
  const icon = isLimitPanelOpened ? 'up' : 'down';
  const panelClassName = isLimitPanelOpened ? 'loadcard-panel__limit--opened' : '';

  return (
    <div className={`loadcard-panel__limit ${panelClassName}`}>
      <h5 className='mrg-btm-none loadcard-panel__title'>
        <a className='' href='#' onClick={(e) => openLimitTab(e)}>
          {labels.limits.replace(`%(level*)s`, idvLevel)}
          <i className={'glyphicon glyphicon-chevron-' + icon}></i>
        </a>
      </h5>
      <TransitionGroup component='div'>
        {isLimitPanelOpened &&
          <IdvPanel
            labels={labels}
            panelData={panelData}
            idvLevel={idvLevel}
          />
        }
      </TransitionGroup>
    </div>
  )
};

class IdvPanel extends React.Component {
  componentDidMount() {
    TweenLite.from(
      this.panel, 0.7,
      {
        height:0,
        y: -20,
        ease: Expo.easeInOut,
        onComplete: () => this.panel.style.height = 'auto'
      }
    );
  }

  componentWillLeave(callback) {
    TweenLite.to(
      this.panel, 0.7,
      {
        height:0,
        y: -20,
        ease: Expo.easeInOut,
        onComplete: callback
      }
    );
  }

  createMarkup(text) {
    return {__html: text};
  }

  render() {
    const {
      labels,
      panelData,
      idvLevel
    } = this.props;

    const {
      nextYearlyAmountLimit,
      limitRemainder,
      yearlyAmountLimit,
      currency
    } = panelData;

    const idvNextLevel = idvLevel + 1;
    const idvRemaining = '<span>' + limitRemainder + ' ' + currency + '</span>';
    const idvAmountLimitLabel = labels.limitation.replace(`%(idvRemaining*)s`, idvRemaining).replace(`%(idvLimit*)s`, yearlyAmountLimit + ' ' + currency);

    let levLabel;

    if(idvLevel === 1) {
      levLabel =
        <span className='details-status mrg-btm-xs'>
          {labels.reminderIdv1.replace(`%(nextLevel*)s`, idvNextLevel).replace(`%(nextAmountLimit*)s`, nextYearlyAmountLimit + ' ' + currency)}
        </span>
    } else {
      levLabel =
        <span className='details-status mrg-btm-xs'>
          {labels.reminderIdv2.replace(`%(nextLevel*)s`, idvNextLevel).replace(`%(nextLevel*)s`, idvNextLevel)}
        </span>
    }

    return(
      <div
        ref={(panel) => this.panel = panel}
        className='loadcard-panel__idv'
      >
        <div className='loadcard-panel__details'>

          <span
            className='details-status mrg-btm-xs'
            dangerouslySetInnerHTML={this.createMarkup(idvAmountLimitLabel)}
          />

          {levLabel}

          {idvLevel < 3 &&
            <a className='btn btn-xcard-main loadcard-panel__btn' href={panelData.idvPageUrl}>
              <span>{labels.upgradeLinkText}</span>
              <span className='glyphicon glyphicon-chevron-right'></span>
            </a>
          }
        </div>
      </div>
    )
  }
}

export default Limit;
