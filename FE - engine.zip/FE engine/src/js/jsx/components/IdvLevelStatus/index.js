// dependencies
import React from 'react';

class IdvLevelStatus extends React.Component {
  constructor() {
    super();

    this.triggerCloseClick = this.triggerCloseClick.bind(this);
  }

  createMarkup(text) {
    return {__html: text};
  }

  triggerCloseClick(e) {
    e.preventDefault(e);

    const closeSelector = e.target.closest('.widget-modal__content').querySelector('.widget-modal__close');
    closeSelector.click();
  }

  render() {
    const {
      labels,
      idvLevel,
      panelData,
    } = this.props;

    const {
      idvPageUrl,
      currency,
      yearlyAmountLimit,
      nextYearlyAmountLimit
    } = panelData;

    const idvNextLevel = idvLevel + 1;
    const idvUpgradeHtmlLink = '<a href="' + idvPageUrl + '">' + i18n.translate('upgrade to').fetch() + '</a>';

    const descr = labels.modalDescriptions.replace('%(level*)s', idvLevel).replace('%(limit*)s', `${yearlyAmountLimit} ${currency}`);
    const descrIdv1 = labels.modalDescriptionsIdv1.replace('%(idvNextLevel*)s', idvNextLevel).replace('%(upgrade to*)', idvUpgradeHtmlLink).replace(`%(nextAmountLimit*)s`, `${nextYearlyAmountLimit} ${currency}`);
    const descrIdv2 = labels.modalDescriptionsIdv2.replace('%(idvNextLevel*)s', idvNextLevel).replace('%(idvNextLevel*)s', idvNextLevel);
    const descrGeneric = labels.modalDescriptionsGeneric;
    const descrBasedOnIdv = idvLevel === 1 ? descrIdv1 : descrIdv2;

    return (
      <div>
        <h3>{labels.modalTitle}</h3>

        <p dangerouslySetInnerHTML={this.createMarkup(descr)} />
        <p dangerouslySetInnerHTML={this.createMarkup(descrBasedOnIdv)} />
        <p dangerouslySetInnerHTML={this.createMarkup(descrGeneric)} />

        <div className='row row-form-inline'>
          <a href={idvPageUrl} className='btn widget-modal__btn btn-xcard-main order-btn pull-left'>
            <span>{labels.modalLinkText}</span>
            <span className='glyphicon glyphicon-chevron-right'></span>
          </a>
          <a
            href='#'
            className='link mrg-top-single mrg-left-xs pull-left'
            onClick={this.triggerCloseClick}
          >
              {labels.modalLinkRejectText}
          </a>
        </div>


      </div>
    )
  }
};

IdvLevelStatus.propTypes = {
  labels: React.PropTypes.object,
  idvLevel: React.PropTypes.number
};

export default IdvLevelStatus;
