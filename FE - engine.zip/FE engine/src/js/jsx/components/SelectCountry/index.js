// dependencies
import React from 'react';

// react Add-Ons module
import enhanceWithClickOutside from 'react-click-outside';

class SelectCountry extends React.Component {

  constructor(props) {
    super(props);

    // bind functions to keep class scope
    this.autoComplete = this.autoComplete.bind(this);
    this.dropDownToggle = this.dropDownToggle.bind(this);
    this.dropDownOpen = this.dropDownOpen.bind(this);
    this.onKeyDown = this.onKeyDown.bind(this);

    // component parent props
    this.fullCountryList = props.options;
    this.defaultCountry = props.defaultCountry || this.fullCountryList[0][0],

    // initial state
    this.state = {
      isShown: false,
      countryList: this.fullCountryList,
      countryName: '',
      countryCode: '',
      itemCounter: 0
    }
  }

  selectOption(country) {
    let c = !country ? this.fullCountryList[0] : country;

    this.lastCountryCode = c[0];
    this.lastCountryName = c[1];

    this.dropDownClose();

    this.setState({
      countryCode: this.lastCountryCode,
      countryName: this.lastCountryName
    }, () => this.props.dispatchSelectedCountry(this.state.countryCode));

  }

  createOptions() {
    return this.state.countryList.map((country, i) => {
      let selectedClass = '';
      const { itemCounter } = this.state;
      const isTouch = Modernizr.touchevents;
      const isSelected = itemCounter === i;
      const countryCode = country[0];
      const countryName = country[1];
      const countryNativeName = country[2];
      const setReference = (item) => this.optionSelectedReference = item;

      if(isSelected && !isTouch) {
        this.optionSelectedAsArray = country;
        selectedClass = ' selected';
      }

      return (
        <li
          key={i}
          ref={(item) => !isTouch && isSelected ? setReference(item) : null}
          className={'select-country__item' + selectedClass}
          onMouseOver={() => !isTouch ? this.hoverList(i) : null}
        >
          <span className='select-country__item__wrap' onClick={() => this.selectOption(country)}>
            <i className={'country-flag flag-' + countryCode.toLowerCase()} />
            <i className='select-country__item__name'>{countryName} ({countryNativeName})</i>
          </span>
        </li>
      );

    });
  }

  hoverList(i) {
    this.setState({
      itemCounter: i
    });
  }

  autoComplete(e) {
    const { value } = e.target;

    let filteredCountryList = this.fullCountryList.filter((country, i) => {
      const countryName = country[1].toLowerCase();
      const countryNativeName = country[2].toLowerCase();
      return countryName.includes(value.toLowerCase()) || countryNativeName.includes(value.toLowerCase());
    });

    this.setState({
      countryName: value,
      countryList: filteredCountryList,
      itemCounter: 0,
      isShown: true
    });
  }

  dropDownToggle() {
    this.setState((prevState) => {
      return {
        isShown: !prevState.isShown,
        countryName: this.lastCountryName,
        countryCode: this.lastCountryCode,
      }
    });
  }

  dropDownOpen() {
    this.inputReference.focus();

    if(!this.state.isShown) {
      this.setState({
        isShown: true,
        countryName: '',
        countryCode: ''
      });
    }
  }

  dropDownClose() {
    if(this.state.isShown) {
      this.setState({
        isShown: false,
        countryList: this.fullCountryList,
        countryName: this.lastCountryName,
        countryCode: this.lastCountryCode,
        itemCounter: 0
      });
    }
  }

  onKeyDown(e) {
    const keyCode = e.keyCode || e.which;
    const { countryList, itemCounter } = this.state;

    if(!this.optionSelectedReference) return null;

    const elH = this.optionSelectedReference.getBoundingClientRect().height;
    const listH = this.listReference.getBoundingClientRect().height;

    switch(keyCode) {
        case 38: {
          // up
          if(itemCounter > 0) {
            this.setState({
              itemCounter: itemCounter - 1
            }, () => {

              if(this.optionSelectedReference.offsetTop < this.listReference.scrollTop) {
                this.listReference.scrollTop -= elH;
              }

            });
          }
        }
        break;

        case 40: {
          // down
          if(itemCounter < countryList.length - 1) {
            this.setState({
              itemCounter: itemCounter + 1
            }, () => {

              if((this.optionSelectedReference.offsetTop + elH) >= (this.listReference.scrollTop + listH)) {
                this.listReference.scrollTop += elH;
              }

            });
          }

        }
        break;

        case 13: {
          e.preventDefault();
          this.selectOption(this.optionSelectedAsArray);
        }
        break;

        default: return null;
    }

  }

  // this is a react Add-Ons methods
  handleClickOutside() {
    this.dropDownClose();
  }

  componentWillMount() {
    // set default country
    const findDefaultCountry = (country) => {
      const countryCode = country[0];
      return countryCode.toLowerCase() === this.defaultCountry.toLowerCase();
    }

    const country = this.state.countryList.find(findDefaultCountry);

    this.selectOption(country);
  }

  render() {
    const { labels, formName } = this.props;
    const { isShown, countryCode, countryName } = this.state;
    const optionList = this.createOptions();
    const icon = isShown ? 'up' : 'down';

    return (
      <div
        className='select-country'
        onKeyDown={this.onKeyDown}
      >
        <input type='hidden' name={formName} value={countryCode} />

        {labels.selectCountryText && labels.selectCountryText != '' &&
          <span className='select-country__title'>{labels.selectCountryText}</span>
        }

        <div className='select-country__combo'>
          <div className='select-country__selected' onClick={this.dropDownOpen}>
            <span
              onClick={this.dropDownToggle}
              className='select-country__selected__dropdown'
            >
              <i className={'country-flag flag-' + countryCode.toLowerCase()} />
              <i className={'glyphicon glyphicon-chevron-' + icon}></i>
            </span>
            <input
              ref={(input) => this.inputReference = input }
              type='text'
              className='select-country__selected__name'
              value={countryName}
              onChange={this.autoComplete}
            />
          </div>

          {isShown &&
            <ul
              ref={(ul) => this.listReference = ul}
              className='select-country__list'>
              {optionList}
            </ul>
          }

        </div>
      </div>
    );
  }
};

SelectCountry.propTypes = {
  labels: React.PropTypes.object,
  defaultCountry: React.PropTypes.string,
  options: React.PropTypes.array.isRequired,
  dispatchSelectedCountry: React.PropTypes.func.isRequired
};

export default enhanceWithClickOutside(SelectCountry);
