// dependencies
import React from 'react';

class LoadCardForm extends React.Component {
  constructor(props) {
    super(props);

    this.handleFormInputs = this.handleFormInputs.bind(this);
    this.knownAccountsAction = this.knownAccountsAction.bind(this);

    this.userCurrency = props.userData.currency;
    this.userAmount = props.userData.amount;
    this.userIban = props.userData.accountNumber;
    this.userBic = props.userData.bankCode;
    this.userBic = props.userData.bankCode;

    this.state = {
      inputCurrency: this.userCurrency.value,
      inputAmount: this.userAmount.value,
      inputAccountIban: this.userIban.value,
      inputAccountBankCode: this.userBic.value,
      inputKnownAccounts: ''
    };
  }

  /* React Transition Group API for animations */
  componentWillLeave(callback) {
    TweenLite.to(this.form, .8, {
      height:0,
      y: -30,
      ease: Expo.easeInOut,
      onComplete: callback
    });
  }

  componentDidEnter() {
    const isTouch = Modernizr.touchevents;

    TweenLite.from(this.form, .8, {
      height: 0,
      y: -30,
      ease: Expo.easeInOut,
      onComplete: () => {
        this.form.removeAttribute('style');

        if(isTouch) {
          this.scrollToSelectedForm();
        }
      }
    });
  }
  /**/

  scrollToSelectedForm() {
    const parentLI = this.form.closest('li');

    if(parentLI) {
      const liOffsetTop = parentLI.getBoundingClientRect().top;
      const header = document.getElementsByClassName('container-header')[0];
      const headerH = header.getBoundingClientRect().height;

      TweenLite.to(window, .5, {
        scrollTo: { y: window.scrollY + liOffsetTop - headerH },
        ease: Expo.easeOut
      });
    }
  }


  get moreDetails() {
    const findLabels = (m) => m['name'] === this.props.payment.methodname;
    return this.props.labels.methodsDescriptions.find(findLabels);
  }

  handleFormInputs(e) {
    this.setState({
      [e.target.id]: e.target.value
    });
  }

  knownAccountsAction(e) {
    this.handleFormInputs(e);

    const val = e.target.value.split(',');

    if(val != '') {
	    this.setState({
        inputAccountIban: val[0],
        inputAccountBankCode: val[1]
      });
    } else {
      this.setState({
        inputAccountIban: '',
        inputAccountBankCode: ''
      });
    }
  }

  render() {
    const { inputAmount, inputCurrency, inputAccountIban, inputAccountBankCode, inputKnownAccounts } = this.state;
    const { labels, payment, userData, countrySelected, paymentMsgError } = this.props;
    const knownAccounts = userData.knownAccounts.value[payment.methodname];

    const curr = payment.currencies;
    const paymentCurrencies = (curr[countrySelected]) ? curr[countrySelected] : curr;
    const hasServerErrorResponse = payment.methodname == userData.method.value && paymentMsgError;

    let msgError;
    let info;
    let moreDescriptions;
    let moreLink;
    let moreList;
    let moreSubDescription;

    if(hasServerErrorResponse) {
      msgError = <div className='alert alert-danger'>{paymentMsgError.map((e,i) => <p key={i}>{e.text}</p>)}</div>;
    }

    if(payment.info) {
      info = payment.info.map((info, i) => <p key={i}>{info}</p>);
    }

    if(this.moreDetails) {
      const { descriptions, link, list, subDescription } = this.moreDetails;

      if(descriptions) {
        moreDescriptions = descriptions.map((d, i) => <span key={i}>{d}</span>);
      }

      if(list) {
        moreList = list.map((l, i) => <li key={i}>{l}</li>);
      }

      if(link) {
        moreLink = <a href={link.href} target={link.target}>{link.text}</a>;
      }

      if(subDescription) {
        moreSubDescription = subDescription.map((d, i) => <p key={i}>{d}</p>);
      }

    }

    const formNames = {
      method: userData.method.formName,
      accountNumber: userData.accountNumber.formName,
      amount: userData.amount.formName,
      currency: userData.currency.formName,
      bankCode: userData.bankCode.formName,
      knownAccounts: userData.knownAccounts.formName
    };

    const amountError = this.userAmount.error;
    const ibanError = this.userIban.error;
    const bicError = this.userBic.error;

    return (
      <div>
        <span className='loadcard-methods__background' />
        <div ref={(form) => this.form = form} className='loadcard-methods__form'>

          <div className='row loadcard-methods__form-wrap'>

            <div className='loadcard-methods__fieldset col-xs-12 col-sm-6'>
              {msgError && msgError}

              <input type='hidden' name={formNames.method} value={payment.methodname} />

              <div className={`form-group${amountError ? ' error has-error' : ''}`}>
                <label className='control-label'>{labels.amountText}</label>
                <div className='row row-form-inline'>
                  <div className='col-sm-8 col-xs-7'>
                    <input
                      id='inputAmount'
                      name={formNames.amount}
                      type='text'
                      className='form-control'
                      value={inputAmount}
                      onChange={this.handleFormInputs}
                    />
                    {amountError &&
                      <span className='help-block'>{amountError}</span>
                    }
                  </div>
                  <div className='col-sm-4 col-xs-5'>
      							<select
                      id='inputCurrency'
                      name={formNames.currency}
                      className='form-control'
                      value={inputCurrency}
                      onChange={this.handleFormInputs}
                    >
                      {paymentCurrencies.map((c, i) => <option key={i} value={c}>{c}</option> )}
      							</select>

      						</div>
                </div>
              </div>

              {payment.requireAccount && (payment.methodname != 'directpay' || countrySelected == 'DE') &&
                <div className='loadcard-methods__account'>

                  {knownAccounts &&
                    <div className='form-group'>
                        <select
                          id='inputKnownAccounts'
                          name={formNames.knownAccounts}
                          onChange={this.knownAccountsAction}
                          value={inputKnownAccounts}
                          className='form-control'
                        >
                          {[['', labels.knownAccountsText]].concat(knownAccounts).map((v, i) =>
                            <option key={i} value={v[0]}>{v[1]}</option>
                          )}
                        </select>
                    </div>
                  }

                  <div className={`form-group${ibanError ? ' error has-error' : ''}`}>
                    <label className='control-label'>{labels.ibanText}</label>
                    <input
                      id='inputAccountIban'
                      type='text'
                      className='form-control'
                      name={formNames.accountNumber}
                      value={inputAccountIban}
                      onChange={this.handleFormInputs}
                    />
                    {ibanError &&
                      <span className='help-block'>{ibanError}</span>
                    }
                  </div>

                  <div className={`form-group${bicError ? ' error has-error' : ''}`}>
                    <label className='control-label'>{labels.bicText}</label>
                    <input
                      id='inputAccountBankCode'
                      type='text'
                      className='form-control'
                      name={formNames.bankCode}
                      value={inputAccountBankCode}
                      onChange={this.handleFormInputs}
                    />
                    {bicError &&
                      <span className='help-block'>{bicError}</span>
                    }
                  </div>
                </div>
              }

          		{!payment.requireAccount && payment.banks &&
          			<div className='form-group' id='payment-account-bankcode'>
      						<select
                    id='inputAccountBankCode'
                    className='form-control'
                    name={formNames.bankCode}
                    value={inputAccountBankCode}
                    onChange={this.handleFormInputs}
                  >
                    {payment.banks.map((v,i) => <option key={i} value={v[1]}>{v[0]}</option> )}
      						</select>
      					</div>
          		}

              <button type='submit' className='btn btn-xcard-main order-btn pull-right'>
                <span>{labels.submit}</span>
                <span className='glyphicon glyphicon-chevron-right'></span>
              </button>

            </div>

            <div className='loadcard-methods__details col-xs-12 col-sm-6'>
              {info && info}
              {moreDescriptions && moreDescriptions}
              {moreList && <ul>{moreList}</ul>}
              {moreLink && moreLink}
              {moreSubDescription && moreSubDescription}
            </div>

          </div>

        </div>
      </div>
    );
  }
};

export default LoadCardForm;
