// dependencies
import React from 'react';

// components
import LoadCardHead from './LoadCardHead';
import LoadCardForm from './LoadCardForm';

// import animation api
import ReactTransitionGroup from 'react-addons-transition-group';

class LoadCardMethods extends React.Component {
  constructor(props) {
    super(props);

    this.countrySelected = props.countrySelected;
    this.selectedPaymentName = props.userData.method.value;
    this.openForm = this.openForm.bind(this);
    this.state = { availableMethods: this.listOfMethods };
  }

  openForm(e, methodName) {
    e.preventDefault();

    this.selectedPaymentName = this.selectedPaymentName != methodName ? methodName : null;
    this.setState({
      availableMethods: this.listOfMethods
    });
  }

  get listOfMethods() {
    const {
      paymentMethods,
      userData,
      labels,
      paymentMsgError
    } = this.props;

    return paymentMethods
      .filter((m) => m.countries.includes(this.countrySelected))
      .map((m, i) => {

        const isOpened = this.selectedPaymentName === m.methodname;
        let deliveryText = m.delivery;

        if(typeof m.delivery === 'object' && m.delivery) {
          deliveryText = m.delivery[this.countrySelected];
          if (!deliveryText) {
            deliveryText = m.delivery[''];
          }
        }

        return (
          <li
            key={i}
            className={'loadcard-methods__item'+ (isOpened ? ' loadcard-methods__item--selected' : '')}
          >
            <LoadCardHead
              name={m.method}
              delivery={deliveryText}
              logo={m.img}
              methodName={m.methodname}
              itemIndex={i}
              isOpened={isOpened}
              openForm={this.openForm}
              highlightInfo={m.highlightInfo}
            />
            <ReactTransitionGroup component='div'>
              {isOpened &&
                <LoadCardForm
                  labels={labels}
                  payment={m}
                  userData={userData}
                  countrySelected={this.countrySelected}
                  paymentMsgError={paymentMsgError}
                />
              }
              </ReactTransitionGroup>
          </li>
        )
      });
  }

  runIntroAnimation() {
    const items = this.methodsList.getElementsByClassName('loadcard-methods__item');

    //the empty '' val is required for the stagger-callback to work
    TweenLite.staggerFrom(items, 0.2, {
      css: { opacity:0, left: -30 }},
      0.1, '', this.scrollToSelectedFormOnPageLoad
    );

  }

  scrollToSelectedFormOnPageLoad() {
    const liSelected = document.getElementsByClassName('loadcard-methods__item--selected')[0];

    if(liSelected) {
      const liOffsetTop = liSelected.getBoundingClientRect().top;
      const header = document.getElementsByClassName('container-header')[0];
      const headerH = header.getBoundingClientRect().height;

      TweenLite.to(window, 1, {
        scrollTo: { y: window.scrollY + liOffsetTop - headerH },
        ease: Expo.easeOut
      });
    }
  }

  componentWillReceiveProps(nextProps) {
    this.selectedPaymentName = null;

    if(nextProps.countrySelected != this.countrySelected) {
      this.countrySelected = nextProps.countrySelected;
      this.setState({
         availableMethods: this.listOfMethods
      });
    }
  }

  componentDidMount() {
    this.runIntroAnimation();
  }

  render() {
    const { selectPayment } = this.props.labels;
    const { availableMethods } = this.state;

    return (
      <div className='loadcard-methods'>
        <h5>{selectPayment}</h5>
        <ul
          ref={(list) => this.methodsList = list }
          className='loadcard-methods__list'>
          {availableMethods}
        </ul>
      </div>
    );
  }
};

LoadCardMethods.propTypes = {
  labels: React.PropTypes.object,
  countrySelected: React.PropTypes.string,
  paymentMsgError: React.PropTypes.array,
  userData: React.PropTypes.object.isRequired,
  paymentMethods: React.PropTypes.array.isRequired
};

export default LoadCardMethods;
