// dependencies
import React from 'react';

const LoadCardHead = ({ name, delivery, highlightInfo, logo, openForm, isOpened, methodName }) => {
  const iconClass = isOpened ? 'up' : 'down';

  return (
    <div className='loadcard-methods__wrap'>
      <a className='loadcard-methods__open' href='#' onClick={(e) => openForm(e, methodName)}></a>
      <i className={`loadcard-methods__icon glyphicon glyphicon-chevron-${iconClass}`}></i>
      <span className='loadcard-methods__title'>{name}</span>
      {delivery &&
        <span className='loadcard-methods__subtitle'>{delivery}</span>
      }
      {
        highlightInfo &&
        <span className='loadcard-methods__subtitle loadcard-methods--hightlight'>{highlightInfo}</span>
      }
      <img className={`loadcard-methods__logo ${methodName}`} src={logo} title={name} />
    </div>
  );
};

export default LoadCardHead;
