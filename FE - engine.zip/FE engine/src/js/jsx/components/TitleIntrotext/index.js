import React from 'react';

const TitleIntrotext = ({ labels }) => {

    const { mainTitle, introText } = labels;

    return (
      <div className='introText'>
        {mainTitle && <h3>{mainTitle}</h3>}
        {introText && <p>{introText}</p>}
      </div>
    );
};

TitleIntrotext.propTypes = {
  labels: React.PropTypes.object
};

export default TitleIntrotext;
