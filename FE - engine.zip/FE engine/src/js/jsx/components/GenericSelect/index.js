// dependencies
import React from 'react';

// react Add-Ons module
import enhanceWithClickOutside from 'react-click-outside';

const NativeSelect = ({val, onChange, optionsList}) => {
  return(
    <select className='gen-select__native' value={val} onChange={onChange}>
      {
        optionsList.map((opt, i) => {
          return (
            <option
              key={i}
              value={opt.value}
            >
              {opt.label}
            </option>
          );
        })
      }
    </select>
  );
};

const CustomSelect = ({isOpened, openCustomSelect, optionSelected, createOptionList}) => {
  const icon = isOpened ? 'up' : 'down';

  return(
    <div className='gen-select'>
      <span className='gen-select__selected' onClick={() => openCustomSelect()}>
        {optionSelected.label}
        <i className={`gen-select__icon glyphicon glyphicon-chevron-${icon}`} />
      </span>
      <input type='hidden' value={optionSelected.value} />

      {isOpened &&
        <ul className='gen-select__list'>
          {createOptionList}
        </ul>
      }
    </div>
  );
};

class GenericSelect extends React.Component {

  constructor(props) {
    super(props);

    this.openCustomSelect = this.openCustomSelect.bind(this);
    this.handleNativeSelect = this.handleNativeSelect.bind(this);
    this.selectOption = this.selectOption.bind(this);

    this.optionSelected = props.optionPreSelected || props.optionsList[0];

    this.itemActive = props.optionsList.indexOf(this.optionSelected);
    this.state = {
      nativeSelectVal: this.optionSelected.value,
      isCustomSelectOpened: false
    }
  }

  componentWillMount() {
    this.props.dispatchSelectedValue(this.optionSelected.value);
  }

  componentWillReceiveProps(nextProps) {
    //if(!Object.isEquivalent(this.props.optionsList, nextProps.optionsList)) {}
    if(!Object.isEquivalent(this.optionSelected, nextProps.optionPreSelected)) {
      this.optionSelected = nextProps.optionPreSelected;
      this.itemActive = nextProps.optionsList.indexOf(this.optionSelected);
      this.props.dispatchSelectedValue(this.optionSelected.value);
    }
  }

  selectOption(opt, i) {
    this.itemActive = i;
    this.optionSelected = opt;
    this.closeCustomSelect();
    this.props.dispatchSelectedValue(opt.value);
  }

  get createOptionList() {
    return this.props.optionsList.map((opt, i) => {

      const isActive = () => {
        if(this.itemActive === i && opt.value !== '') {
          return ' gen-select__item--active';
        }

        return '';
      }

      return (
        <li
          key={i}
          onClick={() => this.optionSelected !== opt && this.selectOption(opt, i)}
          className={`gen-select__item${isActive()}`}
        >
          {opt.label}
        </li>
      );
    })
  }

  handleNativeSelect(e) {
    this.setState({
      nativeSelectVal: e.target.value
    });

    this.props.dispatchSelectedValue(e.target.value);
  }

  openCustomSelect() {
    this.setState((prevState) => {
      return {
        isCustomSelectOpened: !prevState.isCustomSelectOpened
      }
    });
  }

  closeCustomSelect() {
    this.setState({
      isCustomSelectOpened: false
    });
  }

  // this is a react Add-Ons methods
  handleClickOutside() {
    this.closeCustomSelect();
  }

  render() {
    if(Modernizr.touchevents) {
      return <NativeSelect
          val={this.state.nativeSelectVal}
          onChange={this.handleNativeSelect}
          optionsList={this.props.optionsList}
        />
    }

    return (
      <CustomSelect
        isOpened={this.state.isCustomSelectOpened}
        openCustomSelect={this.openCustomSelect}
        optionSelected={this.optionSelected}
        createOptionList={this.createOptionList}
      />
    );
  }
};

GenericSelect.propTypes = {
  labels: React.PropTypes.object,
  optionsList: React.PropTypes.array.isRequired,
  dispatchSelectedValue: React.PropTypes.func.isRequired
};

/*
  otionlist props must match the following structure:

  otionlistName: [
    {
      label: i18n.translate('Please select the type of ID Document').fetch(),
      value: '',
      isPreSelected: true
    },
    ...
  ];

*/

export default enhanceWithClickOutside(GenericSelect);
