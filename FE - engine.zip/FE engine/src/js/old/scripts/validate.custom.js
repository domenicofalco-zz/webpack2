// input field placeholder text not using input values to not conflict with jquery validate
// needs a object of input names and hint text
(function($) {
	$.fn.yakhints = function(params) {
		params = $.extend({}, params);
		// iterate through returned nodes
		this.each(function() {
			$t = $(this);
			$.each(params, function(key, value){
				//takes the inputs that end in a specific pattern set by key.
				var $input = $t.find("input[name$='" + key + "']");
				//create the parent and assign it to variable. give it display and position to anchor hint.
				var $parent = $input.wrap(document.createElement("span")).parent().css({
					//display:"inline-block",
					//position:"relative"
				});
				//create the hint, hide, and append it applying basic top and left positions attaching it to the top left of the parent
				var $hint = $(document.createElement("div")).addClass("yakhint").css({
					position: "absolute",
					left:$input.css("padding-left"), //left should be the padding of the input field to line up with input text
					}).text(value).hide().appendTo($parent);
				//center the hint vertically
				var hintHeight = $hint.height();
				$hint.css({
					top: ($parent.find("input:first").outerHeight() / 2) - (hintHeight / 2),
					height: hintHeight
				});

				//check to make sure the input field is blank
				if($input.val() === "") {
					$hint.show();
				}
				//attach events to disappear and reappear and pass focus
				$hint.click(function(){
					$(this).hide();
					$input.focus();
				});
				$input.focus(function(){
					$hint.hide();
				});
				$input.blur(function(){
					if($(this).val() === "") {
						$hint.show();
					}
				});
			});
		});
		return this;
	};
})(jQuery);

// custom methods for jquery validate and defaults
$.validator.setDefaults({
	//change error class so as to differentiate it from system errors
	errorClass: "validation-error",
	errorPlacement: function(error,elm){
		//treat this different if it is an autocomplete
		var $element = ($(elm).filter("[class$='autocomplete'], [class$='autocomplete ']").length > 0) ? $(elm).parent().find(".ui-autocomplete-input") : $(elm);
		//check to see if the input has a parent that has input-group as a class which signifies it's part of a validation input group (zB birthday)
		//if the input group has a input group parent then the parent is the grandparent.
		var $parent = ($element.parents(".form-group").length > 1) ? $element.parents(".form-group:last") : $element.parents(".form-group:first");

		$parent.css({
			"class": "error-source",
			//position: "relative",
			//display: "inline-block"
		});
		//error.appendTo($parent);
	},
	onkeyup: false, //disable validation when a single key is pressed.
	highlight: function(elm, errorClass) {
		//treat this different if it is an autocomplete
		var $element = ($(elm).filter("[class$='autocomplete'], [class$='autocomplete ']").length > 0) ? $(elm).parent().find(".ui-autocomplete-input") : $(elm);
		//var $element = $(elm);
		if(!$element.hasClass('no-bg-feedback')) {
			$element.animate({
				borderColor:"#F08080",
				backgroundColor:"#FFE4E1"
				}).clearQueue();
		}
	},
	unhighlight: function(elm, errorClass, validClass) {
		//treat this different if it is an autocomplete
		var $element = ($(elm).filter("[class$='autocomplete'], [class$='autocomplete ']").length > 0) ? $(elm).parent().find(".ui-autocomplete-input") : $(elm);
		//var $element = $(elm);
		if ($element.parents(".highlight-gray").length) {
            var borderColor = "#ccc";
        } else {
            var borderColor = "#fff";
		}
		$element.animate({
			borderColor:borderColor,
			backgroundColor:"#fff"
			}).clearQueue();
	},
	//validates the individual input after user leaves the field
	onfocusout: function(element) {
		$(element).blur(function(){
			$(this).valid();
		});
	}
});

$.validator.addMethod("valueGreaterThan", function(value, element, arg){
	return value > arg;
}, messagesJS.validator.value);

$.validator.addMethod("valueLessThan", function(value, element, arg){
	return value < arg;
}, messagesJS.validator.value);

$.validator.addMethod("olderThan", function(value, element, arg){
	var current = new Date();
	var currentYear = current.getFullYear();
	// if user is older than current year minus rule arg, then get them moving along
	if (value < (currentYear - arg)) return true;

	var $parent = $(element).closest(".form-group");
	var day = $parent.find("input[id$='day']").val();
	var month = $parent.find("select[id$='month']").val();

	if (month && day && value) {
		//users birhtdate. subtracting one as javascript starts january at 0 and we start january in select box at 1
		var birthdate = new Date(value, month-1, day);
		//get the date that user must be born before.
		var validDate = new Date(currentYear - arg, current.getMonth(), current.getDate());
		return birthdate <= validDate;
	}
}, messagesJS.validator.olderThan);

$.validator.addMethod("mobilePrefixExist", function(value, element, arg){
	var isMobilePrefixExist = false;
	var prefixValue = value;
	var countryCodes = retreivePhoneCode(null, true);
	//get rid of the + if it exists
	if (prefixValue.substring(0,1) === "+") prefixValue = prefixValue.substring(1);
	//get rid of the first two zeroes, if they exist
	if (prefixValue.substring(0,2) === "00") prefixValue = prefixValue.substring(2);
	//loop through each country code and find a match if applicable
	$.each(countryCodes, function(key, value){
		if (value === prefixValue) {
			isMobilePrefixExist = true;
		}
	});
	return isMobilePrefixExist;
}, messagesJS.validator.mobile);

$.validator.addMethod("isValidGermanIdNumber", function(value, element, arg){
    return value.length == 11 &&
        /^\d+$/.test(value.substring(0,10)) &&
        (parseInt(value[0])*7 + parseInt(value[1])*3 + parseInt(value[2]) +
         parseInt(value[3])*7 + parseInt(value[4])*3 + parseInt(value[5]) +
         parseInt(value[6])*7 + parseInt(value[7])*3 + parseInt(value[8])) % 10 == parseInt(value[9]) &&
        value[10] == "D";
}, messagesJS.validator.validGermanIDNumber);

$.validator.addMethod("regex", function(value, element, regexp) {
		var re = new RegExp(regexp);
		return this.optional(element) || re.test(value);
	}, messagesJS.validator.lettersonly);

//retrieves a phone code based on a passed country code two digit string
function retreivePhoneCode(countryCode, returnAll) {
	var countryPhoneCodes = {
		"AF" : "93", "AL" : "355", "DZ" : "213", "AS" : "1 684", "AD" : "376", "AO" : "244", "AI" : "1 264", "AQ" : "672", "AG" : "1 268",
		"AR" : "54", "AM" : "374", "AW" : "297", "AU" : "61", "AT" : "43", "AZ" : "994", "BS" : "1 242", "BH" : "973", "BD" : "880", "BB" : "1 246",
		"BY" : "375", "BE" : "32", "BZ" : "501", "BJ" : "229", "BM" : "1 441", "BT" : "975", "BO" : "591", "BA" : "387", "BW" : "267", "BR" : "55",
		"VG" : "1 284", "BN" : "673", "BG" : "359", "BF" : "226", "MM" : "95", "BI" : "257", "KH" : "855", "CM" : "237", "CA" : "1", "CV" : "238",
		"KY" : "1 345", "CF" : "236", "TD" : "235", "CL" : "56", "CN" : "86", "CX" : "61", "CC" : "61", "CO" : "57", "KM" : "269", "CG" : "242",
		"CD" : "243", "CK" : "682", "CR" : "506", "HR" : "385", "CU" : "53", "CY" : "357", "CZ" : "420", "DK" : "45", "DJ" : "253", "DM" : "1 767",
		"DO" : "1 809", "TL" : "670", "EC" : "593", "EG" : "20", "SV" : "503", "GQ" : "240", "ER" : "291", "EE" : "372", "ET" : "251", "FK" : "500",
		"FO" : "298", "FJ" : "679", "FI" : "358", "FR" : "33", "PF" : "689", "GA" : "241", "GM" : "220", "GE" : "995", "DE" : "49", "GH" : "233",
		"GI" : "350", "GR" : "30", "GL" : "299", "GD" : "1 473", "GU" : "1 671", "GT" : "502", "GN" : "224", "GW" : "245", "GY" : "592", "HT" : "509",
		"HN" : "504", "HK" : "852", "HU" : "36", "IS" : "354", "IN" : "91", "ID" : "62", "IR" : "98", "IQ" : "964", "IE" : "353", "IM" : "44", "IL" : "972",
		"IT" : "39", "CI" : "225", "JM" : "1 876", "JP" : "81", "JO" : "962", "KZ" : "7", "KE" : "254", "KI" : "686", "KW" : "965", "KG" : "996",
		"LA" : "856", "LV" : "371", "LB" : "961", "LS" : "266", "LR" : "231", "LY" : "218", "LI" : "423", "LT" : "370", "LU" : "352", "MO" : "853",
		"MK" : "389", "MG" : "261", "MW" : "265", "MY" : "60", "MV" : "960", "ML" : "223", "MT" : "356", "MH" : "692", "MR" : "222", "MU" : "230",
		"YT" : "262", "MX" : "52", "FM" : "691", "MD" : "373", "MC" : "377", "MN" : "976", "ME" : "382", "MS" : "1 664", "MA" : "212", "MZ" : "258",
		"NA" : "264", "NR" : "674", "NP" : "977", "NL" : "31", "AN" : "599", "NC" : "687", "NZ" : "64", "NI" : "505", "NE" : "227", "NG" : "234",
		"NU" : "683", "67" : "2", "MP" : "1 670", "KP" : "850", "NO" : "47", "OM" : "968", "PK" : "92", "PW" : "680", "PA" : "507", "PG" : "675",
		"PY" : "595", "PE" : "51", "PH" : "63", "PN" : "870", "PL" : "48", "PT" : "351", "PR" : "1", "QA" : "974", "RO" : "40", "RU" : "7", "RW" : "250",
		"BL" : "590", "WS" : "685", "SM" : "378", "ST" : "239", "SA" : "966", "SN" : "221", "RS" : "381", "SC" : "248", "SL" : "232", "SG" : "65", "SK" : "421",
		"SI" : "386", "SB" : "677", "SO" : "252", "ZA" : "27", "KR" : "82", "ES" : "34", "LK" : "94", "SH" : "290", "KN" : "1 869", "LC" : "1 758", "MF" : "1 599",
		"PM" : "508", "VC" : "1 784", "SD" : "249", "SR" : "597", "SZ" : "268", "SE" : "46", "CH" : "41", "SY" : "963", "TW" : "886", "TJ" : "992",
		"TZ" : "255", "TH" : "66", "TG" : "228", "TK" : "690", "TO" : "676", "TT" : "1 868", "TN" : "216", "TR" : "90", "TM" : "993", "TC" : "1 649",
		"TV" : "688", "AE" : "971", "UG" : "256", "GB" : "44", "UA" : "380", "UY" : "598", "US" : "1", "UZ" : "998", "VU" : "678", "VA" : "39", "VE" : "58",
		"VN" : "84", "VI" : "1 340", "WF" : "681", "YE" : "967", "ZM" : "260", "ZW" : "263"
	};
	if (returnAll) {
		return countryPhoneCodes;
	}

	return countryPhoneCodes[countryCode];
};

//returns the max days in a month. requires a month and a year
function returnDaysFromMonth(month, year) {
	//set year to current year if undefined
	if (!year) year = new Date().getFullYear();
	return new Date(year, month, 0).getDate();
};

function autoFillPhonePrefix(prefixId, countryCode) {
	//if user has changed this themselves, exit and return false.
	if ($(prefixId).data("userchanged")) return false;
	var mobileSymbolPrefix = "+";
	if (countryCode !== "") {
		var phonePrefix = retreivePhoneCode(countryCode);
		$(prefixId).val(mobileSymbolPrefix + phonePrefix);
		return true;
	}
};

//functions from timer.js
function getCookie(c_name) {
	var i,x,y,ARRcookies=document.cookie.split(";");
	for (i=0;i<ARRcookies.length;i++) {
		x=ARRcookies[i].substr(0,ARRcookies[i].indexOf("="));
		y=ARRcookies[i].substr(ARRcookies[i].indexOf("=")+1);
		x=x.replace(/^\s+|\s+$/g,"");
		if (x==c_name) {
			return unescape(y);
		}
	}
	return null;
};

function getTimeout() {
	var cookieTimeout = getCookie('session_timeout');
	if (cookieTimeout) {
		return new Date(parseInt(cookieTimeout) * 1000);
	}
	return new Date(0);
};

function displayLoginTimer(expired, id) {
	var timeout = getTimeout();
	var now = new Date();
	if (now > timeout) {
		window.location.href = expired;
	}
	else {
		var seconds = Math.round((timeout - now) / 1000);
		var secs = (seconds % 60);
		if (secs < 10) secs = '0'+secs;
		var tmp = (seconds - secs) / 60;
		var mins = tmp % 60;
		if (mins < 10) mins = '0'+mins;
		document.getElementById(id).innerHTML = mins+':'+secs;
		setTimeout('displayLoginTimer(\''+expired+'\',\''+id+'\');', 100);
  }
};

function passwordStrength(result) {
	//assign parent container
	var $password = $('.password-strength-indicator');
	//emtpy parent container
	$password.empty();
	//create message container and color container
	var $message = $(document.createElement("span")).addClass("password-strength-text")
						.html(messagesJS.passwordStrength[result.score]).appendTo($password);
	//create color container with the appropriate class. remove class first then add new class
	var $span = $(document.createElement("span")).addClass('pw-strength pw-strength-' + ['poor', 'weak', 'ok', 'good', 'great'][result.score])
						.appendTo($password);
};

$(document).ready(function() {
	//set the default message to use hte messagesJS object for localization
	jQuery.extend(jQuery.validator.messages, {
		required: messagesJS.validator.required,
		remote: messagesJS.validator.remote,
		email: messagesJS.validator.email,
		url: messagesJS.validator.url,
		date: messagesJS.validator.date,
		dateISO: messagesJS.validator.dateISO,
		number: messagesJS.validator.number,
		digits: messagesJS.validator.digits,
		creditcard: messagesJS.validator.creditcard,
		equalTo: messagesJS.validator.equalTo,
		accept: messagesJS.validator.accept,
		maxlength: jQuery.validator.format(messagesJS.validator.maxlength),
		minlength: jQuery.validator.format(messagesJS.validator.minlength),
		rangelength: jQuery.validator.format(messagesJS.validator.rangelength),
		range: jQuery.validator.format(messagesJS.validator.range),
		max: jQuery.validator.format(messagesJS.validator.max),
		min: jQuery.validator.format(messagesJS.validator.min)
	});
});
