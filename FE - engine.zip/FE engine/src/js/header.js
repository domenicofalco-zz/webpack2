// HEADER SCRIPTS
require('jquery');
require('./polyfills');
require('script-loader!./old/vendor/modernizr.js');
require('script-loader!./old/vendor/jquery.cookie.min.js');
require('expose-loader?Jed!./old/vendor/jed.js');
require('script-loader!./old/vendor/bootstrap.min.js');
require('script-loader!./old/vendor/lodash.min.js');
require('script-loader!./old/scripts/utils.js');
require('script-loader!./old/scripts/application.js');
