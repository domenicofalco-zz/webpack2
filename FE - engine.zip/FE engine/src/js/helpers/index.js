/*
  HOW TO USE IN ANOTHER JS TEMPLATE
  ---------------------------------
  ...

  import { maxWidth } from '... /helpers';

  ...

  let w = getWindowSize().width; // it returns a number in px
  let h = getWindowSize().height; // it returns a number in px
  maxWidth(* px value *) // it returns a boolean
*/

// Promise
import { Promise } from 'es6-promise';

function getWindowSize() {
  var v = window;
  var a = 'inner';

  if (!('innerWidth' in v)) {
    a = 'client';
    v = document.documentElement || document.body;
  }

  return {
    width: v[a + 'Width'],
    height: v[a + 'Height'],
  };
}

function minWidth(size) {
  let match = window.matchMedia(`(min-width: ${size}px)`).matches;
  return match ? match : false;
}

function maxWidth(size) {
  let match = window.matchMedia(`(max-width: ${size}px)`).matches;
  return match ? match : false;
}

function promise(u, m, formData, cache) {
  const method = m;
  const url = u;
  const request = new XMLHttpRequest();

  return new Promise((resolve, reject) => {
    request.open(method, url, true);

    request.onload = () => {
      if (request.status >= 200 && request.status < 400) {
        resolve(JSON.parse(request.response));
      } else {
        reject(JSON.parse(request.response));
      }
    };

    request.onerror = (err) => {
      reject(err);
    };

    //avoid cache
    if(!cache) {
      request.setRequestHeader('Pragma', 'no-cache');
    }

    request.send(formData);
  });
}

export { getWindowSize, minWidth, maxWidth, promise };
