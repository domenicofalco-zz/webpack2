// dependencies
const webpack = require('webpack')
const path = require('path')

// add hash extension
const FileChanger = require('webpack-file-changer')
const changesConfig = require('./webpack.build.js')
const fileChanger = new FileChanger(changesConfig)

// environment type
const { NODE_ENV } = process.env;

const GSAPrequire = [
  'gsap/TweenLite',
  'gsap/TimelineLite',
  'gsap/ScrollToPlugin',
  'gsap/EasePack',
  'gsap/CSSPlugin',
  'tweenlite-stagger'
];

/// webpack configuration
const config = {
  context: path.resolve(__dirname, './'),
  entry: {
    header_scripts: './src/js/header.js',
    footer_scripts: './src/js/footer.js',
    main: [...GSAPrequire, './src/js/main.js']
  },
  output: {
    path: path.resolve(__dirname, './wsgi/static/ui/js/'),
    filename: NODE_ENV === 'prepare_prod' ? '[name].[hash].js' : 'uncompressed/[name].bundle.js'
  },
  module: {
    rules: [
      {
        test: /\.js$/,
        exclude: /(node_modules|bower_components)/,
        include: path.resolve(__dirname, './src'),
        use: [{
          loader: 'babel-loader',
          options: {
            presets: [
              ['react'],
              ['es2015', { modules: false }]
            ]
          }
        }]
      },
      {
        test: require.resolve('jquery'),
        use: [{
          loader: 'expose-loader?jQuery'
        }]
      },
      {
        test: require.resolve('jquery'),
        use: [{
          loader: 'expose-loader?$'
        }]
      }
    ]
  },
  plugins: NODE_ENV
    ? [fileChanger]
    : []
}

module.exports = config
